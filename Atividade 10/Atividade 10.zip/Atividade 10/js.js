var janela = document.getElementById("janela");


function abrirJanela(){
	janela.src = "Imagens/aberta.jpg";
}

function fecharJanela(){
	janela.src = "Imagens/fechada.jpg";
}

function quebrarJanela(){
	janela.src = "Imagens/quebrada.jpg";
}