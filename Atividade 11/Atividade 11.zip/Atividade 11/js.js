var texto = document.getElementById("text");
var cbxCapital = document.getElementById("capital");
var cbxSmall = document.getElementById("small");


function mudarTexto(){
    if(cbxCapital.checked){
        cbxSmall.checked=false;
        texto.value = texto.value.toUpperCase();
    }else if(cbxSmall.checked){
        texto.value = texto.value.toLowerCase();
    }
}
function marcaDesmarca(caller) {
    var checks = document.querySelectorAll('input[type="checkbox"]');    
    checks.forEach(c => c.checked = (c == caller) );
  }