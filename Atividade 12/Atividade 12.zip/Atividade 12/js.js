function validar(){

			if(document.forms.formulario1.elements.idNome.value == "" || document.forms.formulario1.elements.idNome.value.length < 10){

				alert("Campo nome inválido, preencha corretamente");

				document.forms.formulario1.elements.idNome.focus();

				return false;

			}

			if (document.forms.formulario1.elements.idEmail.value == "" || document.forms.formulario1.elements.idEmail.value.indexOf('@') == -1 || document.forms.formulario1.elements.idEmail.value.indexOf('.') == -1) {

                alert("Campo Eemail inválido, preencha corretamente");

                document.forms.formulario1.elements.idEmail.focus();

                return false;

            }

            if (document.forms.formulario1.elements.idMensagem.value == "" || document.forms.formulario1.elements.idMensagem.value.length < 20) {
                alert("É necessário ao menos 20 caracteres no comentário!");
                document.getElementById("idMensagem").focus();
                return false;
            }

			
            pesquisa();

			return true;
		}

		function pesquisa(){

			if(document.forms.formulario1.elements["primeiraVez"].value == 2){
				alert("Volte sempre à esta página!");
			} else {
				alert("Que bom que você voltou a visitar esta página!");
			}

		}