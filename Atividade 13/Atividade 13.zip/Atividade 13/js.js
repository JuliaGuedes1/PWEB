function confirmar(){
    confirmado = confirm("Deseja saber mais sobre o curso?");
    if(!confirmado) return;

    cursos = document.getElementById("cursos");

    opcao= cursos.selectedIndex;
 
    novaJanela = window.open("", "janela" + cursos.options[opcao], "fullscreen=yes,width = 600, height = 300");
    novaJanela.document.write("<title>Página do Curso " + cursos.options[opcao].text + "</title>");
    switch (opcao) {
        case 1:
            novaJanela.document.writeln("<p>Curso de Análise e desenvolvimento de sistemas: </p>");
            novaJanela.document.writeln("<p>Carga horária: 2.880 horas</p>");
            novaJanela.document.writeln("<p>Pode ser feito no período da noite e da manhã</p>");
            novaJanela.document.writeln("<p>Este curso tem o intuito de formar profissionais capazes de desenvolver sistemas e de cansar muito os alunos mentalmente.</p>");    
            novaJanela.document.writeln("<p>Para saber mais acesse: http://www.fatecsorocaba.edu.br/curso_ads.asp</p>");
            break;
        case 2:
            novaJanela.document.writeln("<p>Curso de Sistemas biomédicos</p>");
            novaJanela.document.writeln("<p>Carga horária: 2.880 horas</p>");
            novaJanela.document.writeln("<p>Este curso forma profissionais que possam lidar com equipamentos tecnológicos médicos.</p>");
            novaJanela.document.writeln("<p>Para saber mais acesse: http://www.fatecsorocaba.edu.br/curso_sb.asp </p>");
            break;
        case 3:
            novaJanela.document.writeln("<p>Curso de Logística</p>");
            novaJanela.document.writeln("<p>Carga horária a tarde: 2.880 horas</p>");
            novaJanela.document.writeln("<p>Este curso tem o intuito de formar profissionais que lidam com a distribuição de produtos, são os responsáveis por fazer seu produto pedido online chegar até você.</p>");    
            novaJanela.document.writeln("<p>Para saber mais acesse: http://www.fatecsorocaba.edu.br/curso_log.asp</p>");
            break;
    }
}