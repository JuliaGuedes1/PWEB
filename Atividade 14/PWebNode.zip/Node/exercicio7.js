var http = require('http');
var server = http.createServer(function(req,res){
	var opcao =req.url;
	if(opcao=='/historia'){
		res.end("<html><body>Historia da faculdade de tecnologia Fatec Sorocaba</body></html>");
}
	else if (opcao == '/cursos'){
		res.end("<html><body>Cursos</body></html>");
	}
	else if (opcao == '/professores'){
		res.end("<html><body>Professores</body></html>");
	}		
else
	res.end("<html><body>Site da fatec sorocaba</body></html>");
});
server.listen(3000)