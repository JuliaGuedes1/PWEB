alert("Calculando sua média!");

        nome = prompt("Qual é o seu nome?");
     
        
		
		nota1  = prompt("Qual é a sua nota 1?");
		nota2  = prompt("Qual é a sua nota 2?");
		nota3  = prompt("Qual é a sua nota 3?");
		
		media= (parseFloat(nota1)+ parseFloat(nota2) + parseFloat(nota3))/3;
		
		alert("Seu nome é " + nome + " e sua média é: " + media);
		
		
		