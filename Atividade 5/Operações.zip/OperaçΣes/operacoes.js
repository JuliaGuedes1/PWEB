alert("Fazendo operações!");
	num1 = prompt("Digite o primeiro número");
	num2 = prompt("Digite o segundo número");

	num1 = parseFloat(num1);
	num2 = parseFloat(num2);

	alert("A soma dos dois números é :" + (num1 + num2));
	alert("A subtração do primeiro pelo segundo é :" + (num1-num2));
	alert("O produto dos dois é: " + (num1*num2));
	alert("A divisão do primeiro pelo segundo é: " + (num1/num2));
	alert("O resto da divisão do primeiro pelo segundo é: " + (num1%num2));