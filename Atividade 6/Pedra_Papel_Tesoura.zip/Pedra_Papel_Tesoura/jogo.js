alert("Jogando pedra papel e tesoura!");

escolha = prompt("Voce escolhe pedra, papel ou tesoura?");

var computerChoice = Math.random();

if (computerChoice < 0.34) {

computerChoice = "pedra";

} else if(computerChoice <= 0.67) {

computerChoice = "papel";

} else {

computerChoice = "tesoura";

} alert("Computador diz: " + computerChoice);

if (computerChoice === "pedra" &  escolha === "tesoura"){
	alert("Pedra quebra tesoura. Computador venceu");
}

if (escolha === "pedra" &  computerChoice === "tesoura"){
	alert("Pedra quebra tesoura. Você venceu!");
	
}
if (escolha === "tesoura" &  computerChoice === "tesoura"){
	alert("Empate!");
	
}
if (escolha === "pedra" &  computerChoice === "pedra"){
	alert("Empate!");
}
if (escolha === "papel" &  computerChoice === "papel"){
	alert("Empate!");
}

if (computerChoice === "tesoura" &  escolha === "papel"){
	alert("Tesoura corta papel. Computador venceu");
}

if (computerChoice === "papel" &  escolha === "tesoura"){
	alert("Tesoura corta papel. Você venceu!");
}

if (computerChoice === "papel" &  escolha === "pedra"){
	alert("Papel cobre pedra. Computador venceu!");
}
if (computerChoice === "pedra" &  escolha === "papel"){
	alert("Papel cobre pedra. Você venceu!");
}

