num1= prompt("Digite o primeiro número: ");
num2= prompt("Digite o segundo número: ");
num3= prompt("Digite o terceiro número: ");

function maior(num1,num2,num3) {
	if (num1> num2 && num1>num3){
		return("Primeiro número: "+ num1+ " é o maior número");
	}
	if (num2> num1 && num2>num3){
		return("Segundo número: "+ num2 + " é o maior número");
	}
	if (num3>num1 && num3> num2){
		return("Terceiro número: "+ num3 + " é o maior número");
	}
	if (num1==num2 && num1==num3){
		return("Números iguais");
	}
}

alert (maior(num1,num2,num3));