var Aluno1 = {
  ra: '0030481921051',
  nome: 'Luana'
}
alert("RA:" + Aluno1.ra + "\nNome: " + Aluno1.nome);

Aluno1.ra = '0030481921023';
Aluno1.nome = 'Carlos';
alert("RA:" + Aluno1.ra + "\nNome: " + Aluno1.nome);

Aluno1['ra'] = '0030481921018';
Aluno1['nome'] = 'Layla';
alert("RA:" + Aluno1.ra + "\nNome: " + Aluno1.nome);

