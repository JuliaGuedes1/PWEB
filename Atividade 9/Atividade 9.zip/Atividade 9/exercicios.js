function Retangulo(base, altura){
    this.base = base;
    this.altura = altura;
    
    this.calcularArea = () =>{
        return this.base * this.altura;
    };
}

var retangulo = new Retangulo(1,3);
alert("Área do triangulo é: "+ retangulo.calcularArea());


function Conta(){
    var nomeCorrentista;
    var banco;
    var numeroConta;
    var saldo;

    this.setNomeCorrentista = (value)=>{
        this.nomeCorrentista = value;
    };

    this.getNomeCorrentista = ()=>{
        return this.nomeCorrentista;
    };

    this.setBanco = (value) =>{
        this.banco = value;
    }

    this.getBanco = ()=>{
        return this.banco;
    };

    this.setNumeroConta = (value) =>{
        this.numeroConta = value;
    };

    this.getNumeroConta = () =>{
        return this.numeroConta;
    };

    this.setSaldo = (value) =>{
        this.saldo = value;
    };

    this.getSaldo = () =>{
        return this.saldo;
    };
}

function Corrente(){
    var saldoEspecial;

    this.setSaldoEspecial = (value) => {
        this.saldoEspecial = value;
    };

    this.getSaldoEspecial = () => {
        return this.saldoEspecial;
    };
}

function Poupanca(){
    var juros;
    var dataVencimento;

    this.setJuros = (value) => {
        this.juros = value;
    };

    this.getJuros = () =>{
        return this.juros;
    };

    this.setDataVencimento = (value) =>{
        this.dataVencimento = value;
    };

    this.getDataVencimento = () =>{
        return this.dataVencimento;
    };
}

Corrente.prototype = new Conta();
Poupanca.prototype = new Conta();

var contaCorrente = new Corrente();
contaCorrente.setNomeCorrentista("Luiz Fernando");
contaCorrente.setBanco("Banco do Brasil");
contaCorrente.setNumeroConta("001");
contaCorrente.setSaldo("R$ 10.000,00");
contaCorrente.setSaldoEspecial("R$ 1.000,00");

var contaPoupanca = new Poupanca();
contaPoupanca.setNomeCorrentista("Mira Alvez");
contaPoupanca.setBanco("Banco Santander");
contaPoupanca.setNumeroConta("002");
contaPoupanca.setSaldo("R$ 1.100,00");
contaPoupanca.setDataVencimento("10/05/2021");
contaPoupanca.setJuros("2%");

alert("Conta Corrente:" + "\n"
    + "Nome: "+ contaCorrente.getNomeCorrentista() + "\n"
    + "Banco: " + contaCorrente.getBanco() + "\n"
    + "Número da conta: " + contaCorrente.getNumeroConta() + "\n"
    + "Saldo: " + contaCorrente.getSaldo() + "\n"
    + "Saldo especial: " + contaCorrente.getSaldoEspecial()
);

alert("Conta Poupança:" + "\n"
    + "Nome: " + contaPoupanca.getNomeCorrentista() + "\n"
    + "Banco: " + contaPoupanca.getBanco() + "\n"
    + "Número da conta: " + contaPoupanca.getNumeroConta() + "\n"
    + "Saldo: " + contaPoupanca.getSaldo() + "\n"
    + "Data de vencimento: " + contaPoupanca.getDataVencimento() + "\n"
    + "Juros: "+ contaPoupanca.getJuros()
);